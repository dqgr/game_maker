using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block_Create : MonoBehaviour
{
    public GameObject block;
    public GameObject floor;
    Vector3 create_pos;
    public int max = 3;


    private void Awake()
    {
       
        for (int i = 0; i < max; i++)
        {
            this.create_pos = new Vector3(floor.transform.position.x, floor.transform.position.y+5+i, floor.transform.position.z);
            GameObject block_o = Instantiate<GameObject>(block, create_pos, Quaternion.identity); //���� ����
            block_o.transform.localScale = new Vector3((max - i),0.2f, (max - i)); //ũ�� ����
        }
    }
}
