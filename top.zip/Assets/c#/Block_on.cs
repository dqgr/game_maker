using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block_on : MonoBehaviour
{
    public bool block_on_check;
    // Start is called before the first frame update

    private void OnTriggerEnter(Collider other) //������ ���� �ִ��� ������
    {
        if(other.gameObject.tag=="Blocks")
        {
            this.block_on_check = true;
           // Debug.Log("in");
        }
        
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Blocks")
        {
            this.block_on_check = false;
            //Debug.Log("out");
        }
    }
  

}
