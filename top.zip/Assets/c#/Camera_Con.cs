using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_Con : MonoBehaviour
{
    public float Turn_Speed = 4.0f;
    float xRotate = 0f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
        float xRotateSize = -Input.GetAxis("Mouse Y") * Turn_Speed;
        //float xRotateSize = -Input.GetAxis("KeyCode.W") * Turn_Speed;
        xRotate = Mathf.Clamp(xRotate + xRotateSize,-10 , 40); //2��° ��ġ~3��°���� ����
        transform.eulerAngles = new Vector3(xRotate, 0, 0);
    }
}
